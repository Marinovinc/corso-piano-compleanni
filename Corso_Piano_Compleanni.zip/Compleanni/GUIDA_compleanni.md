# Suonare le musiche per i compleanni al pianoforte — guida

`[sessione 3c88c123, 04/10/2026]` — quinto corso della serie, stessa formula. Arrangiamenti facili a
due mani (melodia a destra, accordi a sinistra), per **Synthesia**.

Le musiche sono brani di **pubblico dominio**: la melodia di **Happy Birthday / Tanti auguri** nasce
come "Good Morning to All" (1893) ed e' ormai di pubblico dominio; **For He's a Jolly Good Fellow** e'
una melodia settecentesca. Noi facciamo **arrangiamenti strumentali** (nessun testo stampato), quindi
tutto e' libero. Le melodie sono state prese da notazione e **verificate all'ascolto**.

**Regola d'oro (sempre): prima la mano sinistra, da sola, lentissima.** La destra fa la melodia che
tutti conoscono gia' a memoria: e' il modo piu' facile per cominciare.

---

## Come preparare Synthesia

Cavo **USB "TO HOST"**, seleziona la tastiera come ingresso, apri il file `.mid`, attiva la
**Modalita' di attesa**, studia **una mano alla volta**. Dettagli nella guida della cartella
`Esercizi Boogie Woogie`.

---

## I brani (3)

| # | File | Tonalita' | Note |
|---|---|---|---|
| 1 | `1_Happy_Birthday_facile_DO` | DO | la versione facile, per iniziare |
| 2 | `2_Happy_Birthday_in_FA` | FA | stessa melodia, piu' grave: comoda per **cantarci sopra** |
| 3 | `3_For_Hes_a_Jolly_Good_Fellow` | SOL | "perche' e' un bravo ragazzo", classica alle feste |

Ogni brano ha il suo **MP3** di ascolto. Happy Birthday e' un **valzer** (3/4: *UN-due-tre*);
For He's a Jolly Good Fellow e' in **6/8** (ritmo saltellante). Conta a voce alta all'inizio.

---

## Consigli

- **Due tonalita' per Happy Birthday**: usa il DO per studiare, il FA se devi accompagnare qualcuno
  che canta (spesso e' piu' comodo piu' basso).
- La melodia la conosci: fidati dell'orecchio, ti dice subito se sbagli una nota.
- Gli accordi della sinistra sono pochi e cambiano lentamente: imparali prima da soli.

---

## Onesta' sui file

Melodie di pubblico dominio, prese da notazione e verificate all'ascolto; arrangiamento semplice e
originale, mani separate. Versioni **facili per principianti**, pensate per suonare subito qualcosa di
utile a una festa. Buon divertimento, e un tasto alla volta.
